## Making Changes

- Contributions to this repository are reviewed via Pull Requests before merging.
- Contributions to this repository must follow the [Code Contribution Guidelines].
- At a minimum, all pull requests must:
  - Have a description explaining the problem the contribution solves.
  - Contain a link to a JIRA Task and/or Jira Change Request.
  - Pass `puppet parser validate` command. Do not commit syntax errors.
  - Not contain lint errors. Run all new code through `puppet-lint`.
- See the [Code Contribution Checklist] for a quick reference.

## Code Reviews

If you need help finding a reviewer, try the [#systems] or [#puppet] Slack
channels. More information on how to get started can be found in the
[README](README.md#getting-started).


## Testing

There is great information in the [README](README.md) about getting a Vagrant up
and running. If you choose to use Vagrant, `cd /vagrant` and run `make test`.
See the [README](README.md) for more information about Vagrant, and don't forget
to make a customized `settings.yaml` file.

You may also test directly on your mac. The process is similar. The same testing
commands work on a Mac, but you have to install `puppet` and `puppet-lint`. There's
not much to it. `sudo gem install puppet-lint --no-ri --no-rdoc` and get puppet
here [https://downloads.puppetlabs.com/mac/puppet-3.8.7.dmg].
The run `make test` on your branch. If you have any problems or question, please
ask in [#puppet].

[#systems]: https://twitch.slack.com/messages/C03SYEFUC
[#puppet]: https://twitch.slack.com/messages/C5EQVJB5F
[Code Contribution Guidelines]: https://wiki.twitch.com/display/SYS/Code+Contribution+Guidelines
[Code Contribution Checklist]: https://wiki.twitch.com/display/SYS/Code+Contribution+Checklist
[https://downloads.puppetlabs.com/mac/puppet-3.8.7.dmg]: https://downloads.puppetlabs.com/mac/puppet-3.8.7.dmg
