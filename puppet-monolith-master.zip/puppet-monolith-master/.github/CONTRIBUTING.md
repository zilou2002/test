Thank you for contributing!
===========================

## Developing new Puppet code

### Syntax, Lint & Style

All contributions must be properly linted and syntax checked. This applies to Puppet modules, Yaml (hiera) files, Python scripts, and other languages with available linters and syntax checkers. Some lint warnings are understandably ignorable, but most are not; use your best judgement.

Use [`puppet-lint`](http://puppet-lint.com/) validate commands. Puppet manifests must conform to the [Puppet Language Style Guide](https://puppet.com/docs/puppet/5.5/style_guide.html). Although this style guide is for Puppet 4 and later, and we currently run Puppet 3.8; the majority if not all the document still applies.
