## [JIRA-TICKET] Feature Addition or Breakfix

Describe whether the change made is a planned feature addition or a result of a breakfix operation.

### Description

Describe what changes are being made in this PR. Please provide context on why this change needs to be made.

### Hygiene

- [ ] Code has been linted.
- [ ] Changes have been tested.
